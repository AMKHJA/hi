function rdod(msg)
text = nil
if msg and msg.content and msg.content.text then
text = msg.content.text.text
end
msg_chat_id = msg.chat_id
msg_id = msg.id
if tonumber(msg.sender_id.user_id) == tonumber(Fast) then
return false
end
if text then
local neww = Redis:get(Fast.."Get:Reides:Commands:Group"..msg.chat_id..":"..text)
if neww then
text = neww or text
end
end

if text == "تفعيل ردود السورس" or text == "تعطيل الردود للسورس" then
if not msg.Manger then
return send(msg.chat_id,msg.id,'\n*⋆ هذا الامر يخص '..Controller_Num(6)..' * ',"md",true)
end
Redis:set(Fast..'rb:bna'..msg.chat_id,true)
send(msg.chat_id,msg.id,'\n⋆ تم تفعيل ردود السورس')
end
if text == "تعطيل ردود السورس" or text == "تفعيل الردود السورس" then
if not msg.Manger then
return send(msg.chat_id,msg.id,'\n*⋆ هذا الامر يخص '..Controller_Num(6)..' * ',"md",true)
end
Redis:del(Fast..'rb:bna'..msg.chat_id)
send(msg.chat_id,msg.id,'\n⋆ تم تعطيل ردود السورس')
end
if text == "تفعيل ردود السورس العراقيه" or text == "تفعيل الردود العراقيه" then
if not msg.Manger then
return send(msg.chat_id,msg.id,'\n*⋆ هذا الامر يخص '..Controller_Num(6)..' * ',"md",true)
end
Redis:set(Fast..'Sasa:Jeka'..msg.chat_id,true)
send(msg.chat_id,msg.id,'\n⋆ تم تفعيل امر ردود السورس العراقيه')
end
if text == "تعطيل ردود السورس العراقيه" or text == "تعطيل الردود العراقيه" then
if not msg.Manger then
return send(msg.chat_id,msg.id,'\n*⋆ هذا الامر يخص '..Controller_Num(6)..' * ',"md",true)
end
Redis:del(Fast..'Sasa:Jeka'..msg.chat_id)
send(msg.chat_id,msg.id,'\n⋆ تم تعطيل امر ردود السورس العراقيه')
end

if text == 'هاي' or text == 'هيي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*هاي ورجمه الله وبركاته*',"md",true)  
end
if text == 'سلام عليكم' or text == 'السلام عليكم' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*وعليكم السلام 💜*',"md",true)  
end
if text == 'سلام' or text == 'مع سلامه' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*مع الف سلامه يقلبي متجيش تاني 😹*',"md",true)  
end
if text == 'برايفت' or text == 'تع برايفت' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*خدوني معاكم برايفت والنبي 🥺💔*',"md",true)  
end
if text == 'النبي' or text == 'صلي علي النبي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*عليه الصلاه والسلام 🌝💛*',"md",true)  
end
if text == 'نعم' or text == 'يا نعم' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*نعم الله عليك 🌚❤️*',"md",true)  
end
if text == '🙄' or text == '🙄🙄' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'* نزل عينك تحت كدا علشان هتخاد علي قفاك 😒❤️*',"md",true)  
end
if text == '🙄' or text == '🙄🙄' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*نزل عينك تحت كدا علشان هتخاد علي قفاك 😒❤️*',"md",true)  
end
if text == '😂' or text == '😂😂' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*ضحكتك عثل زيكك ينوحيي 🌝❤️*',"md",true)  
end
if text == '😹' or text == '😹' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*ضحكتك عثل زيكك ينوحيي 🌝❤️*',"md",true)  
end
if text == '🤔' or text == '🤔🤔' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'* بتفكر في اي 🤔*',"md",true)  
end
if text == '🌚' or text == '🌝' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*القمر ده شبهك ❤️*',"md",true)  
end
if text == '💋' or text == '💋💋' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*انا عايز مح انا كمان*',"md",true)  
end
if text == '😭' or text == '😭😭' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*بتعيط تيب لي طيب ?*',"md",true)  
end
if text == '🥺' or text == '🥺🥺' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*متزعلش بحبك ❤️*',"md",true)  
end
if text == '😒' or text == '😒😒' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*عدل وشك ونت بتكلمني 😒*',"md",true)  
end
if text == 'بحبك' or text == 'حبق' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*وانا كمان بعشقك يا روحي ❤️*',"md",true)  
end
if text == 'مح' or text == 'هات مح' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*محات حياتي يروحي ❤️*',"md",true)  
end
if text == 'هلا' or text == 'هلا وغلا' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*هلا بيك ياروحي 👋*',"md",true)  
end
if text == 'هشش' or text == 'هششخرص' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*بنهش كتاكيت احنا هنا ولا اي😹*',"md",true)  
end
if text == 'الحمد الله' or text == 'بخير الحمد الله' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*دايما ياحبيبي*',"md",true)  
end
if text == 'بف' or text == 'بص بف' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*هاجي معاكو*',"md",true)  
end
if text == 'خاص' or text == 'بص خاص' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*ونجيب اشخاص👻*',"md",true)  
end
if text == 'صباح الخير' or text == 'مساء الخير' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*انت الخير يعمري❤️*',"md",true)  
end
if text == 'صباح النور' or text == 'باح الخير' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*صباح العسل 🤍*',"md",true)  
end
if text == 'حصل' or text == 'حثل' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*خخخ امال 😹*',"md",true)  
end
if text == 'اه' or text == 'اها' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*اه اي يجدع عيب*',"md",true)  
end
if text == '.' or text == '?' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*صلي علي محمد*',"md",true)  
end
if text == '..' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*لا اله الا الله*',"md",true)  
end
if text == '...' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*استغفـر الله العظيم ❤️*',"md",true)  
end
if text == 'كسم' or text == 'كسمك' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*عيب ياوسخ *',"md",true)  
end
if text == 'بوتي' or text == 'يا بوتي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'روح وعقل بوتك',"md",true)  
end
if text == 'متيجي' or text == 'تع' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*لا عيب بتكسف*',"md",true)  
end
if text == 'هيح' or text == 'لسه صاحي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*صح النوم*',"md",true)  
end
if text == 'منور' or text == 'نورت' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*ده نورك ي قلبي*',"md",true)  
end
if text == 'باي' or text == 'انا ماشي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*ع فين لوين رايح وسايبنى*',"md",true)  
end
if text == 'ويت' or text == 'ويت يحب' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*اي الثقافه دي 😹*',"md",true)  
end
if text == 'خخخ' or text == 'خخخخخ' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*اهدا يوحش ميصحش كدا 😹*',"md",true)  
end
if text == 'شكرا' or text == 'مرسي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*العفو ياروحي 🙈*',"md",true)  
end
if text == 'حلوه' or text == 'حلو' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*انت الي حلو ياقمر 🌝*',"md",true)  
end
if text == 'بموت' or text == 'هموت' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*موت بعيد م ناقصين مصايب 😂*',"md",true)  
end
if text == 'اي' or text == 'ايه' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*جتك اوهه م سامع ولا ايي 😹*',"md",true)  
end
if text == 'طيب' or text == 'تيب' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*فرح خالتك قريب 😹*',"md",true)  
end
if text == 'حاضر' or text == 'حتر' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*حضرلك الخير يارب ❤️*',"md",true)  
end
if text == 'جيت' or text == 'انا جيت' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'* لف ورجع تانى مشحوار 😂*',"md",true)  
end
if text == 'بخ' or text == 'عو' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*تصدق خوفت يخي*',"md",true)  
end
if text == 'حبيبي' or text == 'حبيبتي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*اوه ياه 😂*',"md",true)  
end
if text == 'تمام' or text == 'تمم' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'* امك اسمها احلام 😹*',"md",true)  
end
if text == 'خلاص' or text == 'خلص' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*خلصتت روحكك يبعيد 😹*',"md",true)  
end
if text == 'سي في' or text == 'سيفي' then
if not Redis:get(Fast.."rb:bna"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*كفيه شقط سيب حاجه لغيرك 😂*',"md",true)  
end
if text == '،' or text == '،،،' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*تـدوم عمࢪيي💘 ️*',"md",false, false, false, false, reply_markup)
end
if text == '😐' or text == '🙂' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'* شـبي حـلـو صـافـن😻💋 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'اريد اكبل' or text == 'ارتبط' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*امـشي وخࢪ مـنـا يدوࢪ تـڪـبيل😏 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'لتزحف' or text == 'زاحف' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*شـعليڪ بـي عمࢪيي خـلي يـزحف💘☹️ ️*',"md",false, false, false, false, reply_markup)
end

if text == 'كلخره' or text == 'كل خره' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*اسـف عمࢪيي مـا خليڪ بـحـلڪي😹💘 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'زحف' or text == 'زاحفه' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*زاحـف ع خـالـڪ شـڪࢪه🤤💋 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'دي' or text == 'دد' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*امـشـيڪ بـيها عمࢪيي😗😹 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'فرخ' or text == 'كحبه' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*ويـنـه بـلـه خـل حـصـࢪه😹🤤 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'تعالي خاص' or text == 'خاص' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*هااا يـول اخـذتـها خـاص😹🙊 ️*',"md",false, false, false, false, reply_markup)
end
if text == 'اكرهك' or text == 'اكرهج' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*عـساس انـي مـيـت بيڪڪ دمـشـي لڪ😿😹 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'احبك' or text == 'احبج' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*يـحـياتـي وانـي هـم حـبـڪڪ🙈💋️*',"md",false, false, false, false, reply_markup)
end

if text == 'باي' or text == 'سيو' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*ويـن دايـح عمࢪيي خـلـينـا مـونـسـيـن🥺💘️*',"md",false, false, false, false, reply_markup)
end

if text == 'عوائل' or text == 'صايره عوائل' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*حـبيـبي ولله ࢪبـط فـيـشه ويـانـا🙈💋 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'واكف' or text == 'وكف' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*شـغال عمࢪيي🤓💘 ️*',"md",false, false, false, false, reply_markup)
end


if text == 'وين المدير' or text == 'المدير' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*عمࢪيي تـفـضل وياڪ مـديـࢪ💘️*',"md",false, false, false, false, reply_markup)
end
if text == 'انجب' or text == 'نجبي' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*صـاࢪ عمࢪيي💘🥺 ️*',"md",false, false, false, false, reply_markup)
end

if text == 'تحبني' or text == 'تحبيني' then
if not Redis:get(Fast.."Sasa:Jeka"..msg_chat_id) then
return bot.sendText(msg_chat_id,msg_id,"* *","md",true)  
end
return bot.sendText(msg_chat_id,msg_id,'*سـؤال صـعـب خلـيـني افڪࢪ☹️️*',"md",false, false, false, false, reply_markup)
end
end
return {Fast = rdod}