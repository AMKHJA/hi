function tran(msg)
text = nil
if msg and msg.content and msg.content.text then
text = msg.content.text.text
end
if tonumber(msg.sender_id.user_id) == tonumber(Fast) then
return false
end
if text then
local neww = Redis:get(Fast.."Get:Reides:Commands:Group"..msg.chat_id..":"..text)
if neww then
text = neww or text
end
end
if text and Redis:get(Fast.."toar"..msg.sender_id.user_id) then
Redis:del(Fast.."toar"..msg.sender_id.user_id)
local json = json:decode(https.request("https://ayad-12.xyz/7oda.php?from=auto&to=ar&text="..text)).result
send(msg.chat_id,msg.id,json,"html",true)
end
if text and Redis:get(Fast.."toen"..msg.sender_id.user_id) then
Redis:del(Fast.."toen"..msg.sender_id.user_id)
local json = json:decode(https.request("https://ayad-12.xyz/7oda.php?from=auto&to=en&text="..text)).result
send(msg.chat_id,msg.id,json,"html",true)
end
if text == 'ترجمه' or text == 'ترجمة' or text == 'ترجم' or text == 'translat' then 
local reply_markup = bot.replyMarkup{
type = 'inline',
data = {
{{text = 'الي العربية', data = msg.sender_id.user_id..'toar'}},
{{text = 'الي الانجليزية', data = msg.sender_id.user_id..'toen'}},
}
}
return send(msg.chat_id,msg.id, [[*
⋆ حسنا اختر نوع الترجمه .
*]],"md",false, false, false, false, reply_markup)
end




end

return {Fast = tran}