function bank(msg)
text = nil
if msg and msg.content and msg.content.text then
text = msg.content.text.text
end
if tonumber(msg.sender_id.user_id) == tonumber(Fast) then
return false
end
if text then
local neww = Redis:get(Fast.."Get:Reides:Commands:Group"..msg.chat_id..":"..text)
if neww then
text = neww or text
end
end
if msg.reply_to_message_id ~= 0 then
local mrply = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
if mrply and mrply.sender_id then
rep_idd = mrply.sender_id.user_id or mrply.sender_id.chat_id
end
end
if text == 'انشاء حساب بنكي' or text == 'انشاء حساب البنكي' or text =='انشاء الحساب بنكي' or text =='انشاء الحساب البنكي' or text == "انشاء حساب" or text == "فتح حساب بنكي" then
cobnum = tonumber(Redis:get(Fast.."bandid"..msg.sender_id.user_id))
if cobnum == msg.sender_id.user_id then
return bot.sendText(msg.chat_id,msg.id, "⋆ حسابك محظور من لعبة البنك","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
creditcc = math.random(5000000000000,5999999999999);
creditvi = math.random(4000000000000,4999999999999);
creditex = math.random(6000000000000,6999999999999);
balas = 50
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
return bot.sendText(msg.chat_id,msg.id, "⋆ لديك حساب بنكي مسبقاً\n\n⋆ لعرض معلومات حسابك اكتب\n⇠ `حسابي`","md",true)
end
Redis:setex(Fast.."booobb" .. msg.chat_id .. ":" .. msg.sender_id.user_id,60, true)
bot.sendText(msg.chat_id,msg.id,[[
⋆ لانشاء حساب قم باختيار نوع البطاقة
ــــــــــــــــــــــــــــــــــــــــــــــــــ
‍• `ماستر`
‍• `فيزا`
‍• `اكسبرس`
ــــــــــــــــــــــــــــــــــــــــــــــــ
- اضغط للنسخ
⋆ مدة الطلب دقيقة واحدة ويطردك الموظف
]],"md",true)  
return false
end
if Redis:get(Fast.."booobb" .. msg.chat_id .. ":" .. msg.sender_id.user_id) then
if text == "ماستر" then
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
news = ""..ban.first_name..""
else
news = " لا يوجد"
end
local banid = msg.sender_id.user_id
Redis:set(Fast.."bobna"..msg.sender_id.user_id,news)
Redis:set(Fast.."boob"..msg.sender_id.user_id,balas)
Redis:set(Fast.."boobb"..msg.sender_id.user_id,creditcc)
Redis:set(Fast.."bbobb"..msg.sender_id.user_id,text)
Redis:set(Fast.."boballname"..creditcc,news)
Redis:set(Fast.."boballbalc"..creditcc,balas)
Redis:set(Fast.."boballcc"..creditcc,creditcc)
Redis:set(Fast.."boballban"..creditcc,text)
Redis:set(Fast.."boballid"..creditcc,banid)
Redis:sadd(Fast.."booob",msg.sender_id.user_id)
Redis:del(Fast.."booobb" .. msg.chat_id .. ":" .. msg.sender_id.user_id) 
bot.sendText(msg.chat_id,msg.id, "\n⋆ تم انشاء حسابك في بنك جولد 🏦\n⋆ وشحنالك 50 دولار 💸 هدية\n\n⋆ رقم حسابك ↜ ( `"..creditcc.."` )\n⋆ نوع البطاقة ↜ ( ماستر 💳 )\n⋆ فلوسك ↜ ( 50 دولار 💸 )  ","md",true)  
end 
if text == "فيزا" then
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
news = ""..ban.first_name..""
else
news = " لا يوجد"
end
local banid = msg.sender_id.user_id
Redis:set(Fast.."bobna"..msg.sender_id.user_id,news)
Redis:set(Fast.."boob"..msg.sender_id.user_id,balas)
Redis:set(Fast.."boobb"..msg.sender_id.user_id,creditvi)
Redis:set(Fast.."bbobb"..msg.sender_id.user_id,text)
Redis:set(Fast.."boballname"..creditvi,news)
Redis:set(Fast.."boballbalc"..creditvi,balas)
Redis:set(Fast.."boballcc"..creditvi,creditvi)
Redis:set(Fast.."boballban"..creditvi,text)
Redis:set(Fast.."boballid"..creditvi,banid)
Redis:sadd(Fast.."booob",msg.sender_id.user_id)
Redis:del(Fast.."booobb" .. msg.chat_id .. ":" .. msg.sender_id.user_id) 
bot.sendText(msg.chat_id,msg.id, "\n⋆ تم انشاء حسابك في بنك جولد 🏦\n⋆ وشحنالك 50 دولار 💸 هدية\n\n⋆ رقم حسابك ↜ ( `"..creditvi.."` )\n⋆ نوع البطاقة ↜ ( فيزا 💳 )\n⋆ فلوسك ↜ ( 50 دولار 💸 )  ","md",true)   
end 
if text == "اكسبرس" then
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
news = ""..ban.first_name..""
else
news = " لا يوجد"
end
local banid = msg.sender_id.user_id
Redis:set(Fast.."bobna"..msg.sender_id.user_id,news)
Redis:set(Fast.."boob"..msg.sender_id.user_id,balas)
Redis:set(Fast.."boobb"..msg.sender_id.user_id,creditex)
Redis:set(Fast.."bbobb"..msg.sender_id.user_id,text)
Redis:set(Fast.."boballname"..creditex,news)
Redis:set(Fast.."boballbalc"..creditex,balas)
Redis:set(Fast.."boballcc"..creditex,creditex)
Redis:set(Fast.."boballban"..creditex,text)
Redis:set(Fast.."boballid"..creditex,banid)
Redis:sadd(Fast.."booob",msg.sender_id.user_id)
Redis:del(Fast.."booobb" .. msg.chat_id .. ":" .. msg.sender_id.user_id) 
bot.sendText(msg.chat_id,msg.id, "\n⋆ تم انشاء حسابك في بنك جولد 🏦\n⋆ وشحنالك 50 دولار 💸 هدية\n\n⋆ رقم حسابك ↜ ( `"..creditex.."` )\n⋆ نوع البطاقة ↜ ( اكسبرس 💳 )\n⋆ فلوسك ↜ ( 50 دولار 💸 )  ","md",true)   
end 
end
if text == 'مسح حساب بنكي' or text == 'مسح حساب البنكي' or text =='مسح الحساب بنكي' or text =='مسح الحساب البنكي' or text == "مسح حسابي البنكي" or text == "مسح حسابي بنكي" or text == "مسح حسابي" then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
Redis:srem(Fast.."booob", msg.sender_id.user_id)
Redis:del(Fast.."boob"..msg.sender_id.user_id)
Redis:del(Fast.."boobb"..msg.sender_id.user_id)
Redis:del(Fast.."rrfff"..msg.sender_id.user_id)
Redis:srem(Fast.."rrfffid", msg.sender_id.user_id)
Redis:srem(Fast.."roogg1", msg.sender_id.user_id)
Redis:srem(Fast.."roogga1", msg.sender_id.user_id)
Redis:del(Fast.."roog1"..msg.sender_id.user_id)
Redis:del(Fast.."rooga1"..msg.sender_id.user_id)
Redis:del(Fast.."rahr1"..msg.sender_id.user_id)
Redis:del(Fast.."rahrr1"..msg.sender_id.user_id)
bot.sendText(msg.chat_id,msg.id, "⋆ مسحت حسابك البنكي 🏦","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'تثبيت النتائج' or text == 'تثبيت نتائج' then
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
time = os.date("*t")
month = time.month
day = time.day
local_time = month.."/"..day
local bank_users = Redis:smembers(Fast.."booob")
if #bank_users == 0 then
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يوجد حسابات في البنك","md",true)
end
mony_list = {}
for k,v in pairs(bank_users) do
local mony = Redis:get(Fast.."boob"..v)
table.insert(mony_list, {tonumber(mony) , v})
end
table.sort(mony_list, function(a, b) return a[1] > b[1] end)
num = 1
emoji ={ 
"🥇",
"🥈",
"🥉"
}
for k,v in pairs(mony_list) do
local user_name = bot.getUser(v[2]).first_name or Redis:get(v[2].."first_name:") or "لا يوجد اسم"
local mony = v[1]
local convert_mony = string.format("%.0f",mony)
local emo = emoji[k]
num = num + 1
Redis:set(Fast.."medal"..v[2],convert_mony)
Redis:set(Fast.."medal2"..v[2],emo)
Redis:set(Fast.."medal3"..v[2],local_time)
Redis:sadd(Fast.."medalid",v[2])
Redis:set(Fast.."medal"..v[2],convert_mony)
Redis:set(Fast.."medal2"..v[2],emo)
Redis:set(Fast.."medal3"..v[2],local_time)
Redis:sadd(Fast.."medalid",v[2])
local user_name = bot.getUser(v[2]).first_name or Redis:get(v[2].."first_name:") or "لا يوجد اسم"
local user_tag = '['..user_name..'](tg://user?id='..v[2]..')'
local mony = v[1]
local convert_mony = string.format("%.0f",mony)
local emo = emoji[k]
num = num + 1
Redis:set(Fast.."medal"..v[2],convert_mony)
Redis:set(Fast.."medal2"..v[2],emo)
Redis:set(Fast.."medal3"..v[2],local_time)
Redis:sadd(Fast.."medalid",v[2])
if num == 4 then
return end
end
bot.sendText(msg.chat_id,msg.id, "⋆ ثبتت النتائج","md",true)
end
end
if text == 'مسح كل الفلوس' or text == 'مسح كل فلوس' then
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
local bank_users = Redis:smembers(Fast.."booob")
for k,v in pairs(bank_users) do
Redis:del(Fast.."boob"..v)
Redis:del(Fast.."kreednum"..v)
Redis:del(Fast.."kreed"..v)
Redis:del(Fast.."rrfff"..v)
end
local bank_usersr = Redis:smembers(Fast.."rrfffid")
for k,v in pairs(bank_usersr) do
Redis:del(Fast.."boob"..v)
Redis:del(Fast.."rrfff"..v)
end
bot.sendText(msg.chat_id,msg.id, "⋆ مسحت كل فلوس اللعبة 🏦","md",true)
end
end

if text == 'تصفير النتائج' or text == 'مسح لعبه البنك' then
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
local bank_users = Redis:smembers(Fast.."booob")
for k,v in pairs(bank_users) do
Redis:del(Fast.."boob"..v)
Redis:del(Fast.."kreednum"..v)
Redis:del(Fast.."kreed"..v)
Redis:del(Fast.."rrfff"..v)
Redis:del(Fast.."numattack"..v)
end
local bank_usersr = Redis:smembers(Fast.."rrfffid")
for k,v in pairs(bank_usersr) do
Redis:del(Fast.."boob"..v)
Redis:del(Fast.."rrfff"..v)
end
Redis:del(Fast.."rrfffid")
Redis:del(Fast.."booob")
bot.sendText(msg.chat_id,msg.id, "⋆ مسحت لعبه البنك 🏦","md",true)
end
end
if text == 'ميدالياتي' or text == 'ميداليات' then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."medalid",msg.sender_id.user_id) then
local medaa2 = Redis:get(Fast.."medal2"..msg.sender_id.user_id)
if medaa2 == "🥇" then
local medaa = Redis:get(Fast.."medal"..msg.sender_id.user_id)
local medaa2 = Redis:get(Fast.."medal2"..msg.sender_id.user_id)
local medaa3 = Redis:get(Fast.."medal3"..msg.sender_id.user_id)
bot.sendText(msg.chat_id,msg.id, "ميدالياتك :\n\nالتاريخ : "..medaa3.." \nالفلوس : "..medaa.." 💸\nالمركز : "..medaa2.." كونكر "..medaa2.."","md",true)
elseif medaa2 == "🥈" then
local medaa = Redis:get(Fast.."medal"..msg.sender_id.user_id)
local medaa2 = Redis:get(Fast.."medal2"..msg.sender_id.user_id)
local medaa3 = Redis:get(Fast.."medal3"..msg.sender_id.user_id)
bot.sendText(msg.chat_id,msg.id, "ميدالياتك :\n\nالتاريخ : "..medaa3.." \nالفلوس : "..medaa.." 💸\nالمركز : "..medaa2.." ايس "..medaa2.."","md",true)
else
local medaa = Redis:get(Fast.."medal"..msg.sender_id.user_id)
local medaa2 = Redis:get(Fast.."medal2"..msg.sender_id.user_id)
local medaa3 = Redis:get(Fast.."medal3"..msg.sender_id.user_id)
bot.sendText(msg.chat_id,msg.id, "ميدالياتك :\n\nالتاريخ : "..medaa3.." \nالفلوس : "..medaa.." 💸\nالمركز : "..medaa2.." تاج "..medaa2.."","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك ميداليات","md",true)
end
end

if text == 'فلوسي' or text == 'فلوس' and tonumber(msg.reply_to_message_id) == 0 then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(ballancee) < 1 then
return bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك فلوس ارسل الالعاب وابدأ بجمع الفلوس","md",true)
end
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك `"..convert_mony.."` دولار 💸","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'فلوسه' or text == 'فلوس' and tonumber(msg.reply_to_message_id) ~= 0 then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ ليس لديه حساب في بنك جولد*","md",true)  
return false
end
if Redis:sismember(Fast.."booob",Remsg.sender_id.user_id) then
ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballanceed)
bot.sendText(msg.chat_id,msg.id, "⋆ فلوسه `"..convert_mony.."` دولار 💸","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعنده حساب بنكي ","md",true)
end
end

if text == 'حسابي' or text == 'حسابي البنكي' or text == 'رقم حسابي' then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
news = ""..ban.first_name..""
else
news = " لا يوجد"
end
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
cccc = Redis:get(Fast.."boobb"..msg.sender_id.user_id)
uuuu = Redis:get(Fast.."bbobb"..msg.sender_id.user_id)
pppp = Redis:get(Fast.."rrfff"..msg.sender_id.user_id) or 0
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id, "⋆ الاسم ↜ "..news.."\n⋆ الحساب ↜ `"..cccc.."`\n⋆ بنك ↜ ( جولد )\n⋆ نوع ↜ ( "..uuuu.." )\n⋆ الرصيد ↜ ( "..convert_mony.." دولار 💸 )\n⋆ الزرف ( "..pppp.." دولار 💸 )","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'مسح حسابه' and tonumber(msg.reply_to_message_id) ~= 0 then
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ ليس لديه حساب في بنك جولد*","md",true)  
return false
end
local ban = bot.getUser(Remsg.sender_id.user_id)
if ban.first_name then
news = ""..ban.first_name..""
else
news = " لا يوجد"
end
if Redis:sismember(Fast.."booob",Remsg.sender_id.user_id) then
ccccc = Redis:get(Fast.."boobb"..Remsg.sender_id.user_id)
uuuuu = Redis:get(Fast.."bbobb"..Remsg.sender_id.user_id)
ppppp = Redis:get(Fast.."rrfff"..Remsg.sender_id.user_id) or 0
ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballanceed)
Redis:srem(Fast.."booob", Remsg.sender_id.user_id)
Redis:del(Fast.."boob"..Remsg.sender_id.user_id)
Redis:del(Fast.."boobb"..Remsg.sender_id.user_id)
Redis:del(Fast.."rrfff"..Remsg.sender_id.user_id)
Redis:del(Fast.."numattack"..Remsg.sender_id.user_id)
Redis:srem(Fast.."rrfffid", Remsg.sender_id.user_id)
Redis:srem(Fast.."roogg1", Remsg.sender_id.user_id)
Redis:srem(Fast.."roogga1", Remsg.sender_id.user_id)
Redis:del(Fast.."roog1"..Remsg.sender_id.user_id)
Redis:del(Fast.."rooga1"..Remsg.sender_id.user_id)
Redis:del(Fast.."rahr1"..Remsg.sender_id.user_id)
Redis:del(Fast.."rahrr1"..Remsg.sender_id.user_id)
bot.sendText(msg.chat_id,msg.id, "⋆ الاسم ↜ "..news.."\n⋆ الحساب ↜ `"..ccccc.."`\n⋆ بنك ↜ ( جولد )\n⋆ نوع ↜ ( "..uuuuu.." )\n⋆ الرصيد ↜ ( "..convert_mony.." دولار 💸 )\n⋆ الزرف ↜ ( "..ppppp.." دولار 💸 )\n⋆ مسكين مسحت حسابه","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ليس لديه حساب في البنك ","md",true)
end
end
end

if text == 'حسابه' and tonumber(msg.reply_to_message_id) ~= 0 then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ ليس لديه حساب في بنك جولد*","md",true)  
return false
end
local ban = bot.getUser(Remsg.sender_id.user_id)
if ban.first_name then
news = ""..ban.first_name..""
else
news = " لا يوجد"
end
if Redis:sismember(Fast.."booob",Remsg.sender_id.user_id) then
ccccc = Redis:get(Fast.."boobb"..Remsg.sender_id.user_id)
uuuuu = Redis:get(Fast.."bbobb"..Remsg.sender_id.user_id)
ppppp = Redis:get(Fast.."rrfff"..Remsg.sender_id.user_id) or 0
ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballanceed)
bot.sendText(msg.chat_id,msg.id, "⋆ الاسم ↜ "..news.."\n⋆ الحساب ↜ `"..ccccc.."`\n⋆ بنك ↜ ( جولد )\n⋆ نوع ↜ ( "..uuuuu.." )\n⋆ الرصيد ↜ ( "..convert_mony.." دولار 💸 )\n⋆ الزرف ↜ ( "..ppppp.." دولار 💸 )","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعنده حساب بنكي ","md",true)
end
end

if text and text:match('^مسح حساب (.*)$') or text and text:match('^مسح حسابه (.*)$') then
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
local UserName = text:match('^مسح حساب (.*)$') or text:match('^مسح حسابه (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
local ban = bot.getUser(coniss)
if ban.first_name then
news = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
news = " لا يوجد "
end
if Redis:sismember(Fast.."booob",coniss) then
ccccc = Redis:get(Fast.."boobb"..coniss)
uuuuu = Redis:get(Fast.."bbobb"..coniss)
ppppp = Redis:get(Fast.."rrfff"..coniss) or 0
ballanceed = Redis:get(Fast.."boob"..coniss) or 0
local convert_mony = string.format("%.0f",ballanceed)
Redis:srem(Fast.."booob", coniss)
Redis:del(Fast.."boob"..coniss)
Redis:del(Fast.."boobb"..coniss)
Redis:del(Fast.."rrfff"..coniss)
Redis:srem(Fast.."roogg1", coniss)
Redis:srem(Fast.."roogga1", coniss)
Redis:del(Fast.."roog1"..coniss)
Redis:del(Fast.."rooga1"..coniss)
Redis:del(Fast.."rahr1"..coniss)
Redis:del(Fast.."rahrr1"..coniss)
Redis:del(Fast.."numattack"..coniss)
Redis:srem(Fast.."rrfffid", coniss)
bot.sendText(msg.chat_id,msg.id, "⋆ الاسم ↜ "..news.."\n⋆ الحساب ↜ `"..ccccc.."`\n⋆ بنك ↜ ( جولد )\n⋆ نوع ↜ ( "..uuuuu.." )\n⋆ الرصيد ↜ ( "..convert_mony.." دولار 💸 )\n⋆ الزرف ↜ ( "..ppppp.." دولار 💸 )\n⋆ مسكين مسحت حسابه","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ليس لديه حساب في البنك ","md",true)
end
end
end

if text and text:match('^حساب (.*)$') or text and text:match('^حسابه (.*)$') then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local UserName = text:match('^حساب (.*)$') or text:match('^حسابه (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if Redis:get(Fast.."boballcc"..coniss) then
local yty = Redis:get(Fast.."boballname"..coniss)
local bobpkh = Redis:get(Fast.."boballid"..coniss)
ballancee = Redis:get(Fast.."boob"..bobpkh) or 0
local convert_mony = string.format("%.0f",ballancee)
local dfhb = Redis:get(Fast.."boballbalc"..coniss)

local fsvhh = Redis:get(Fast.."boballban"..coniss)
bot.sendText(msg.chat_id,msg.id, "⋆ الاسم ↜ "..yty.."\n⋆ الحساب ↜ `"..coniss.."`\n⋆ بنك ↜ ( جولد )\n⋆ نوع ↜ ( "..fsvhh.." )\n⋆ الرصيد ↜ ( "..convert_mony.." دولار 💸 )","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ مافيه حساب بنكي كذا","md",true)
end
end

if text == 'مضاربه' then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
if Redis:get(Fast.."iiooooo" .. msg.sender_id.user_id) then
local time = ctime(Redis:ttl(Fast.."iiooooo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يمكنك تضارب الان\n⋆ تعال بعد ( "..time.." )","md",true)
end
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`مضاربه` المبلغ","md",true)
end

if text and text:match('^مضاربه (.*)$') or text and text:match('^مضاربة (.*)$') then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local UserName = text:match('^مضاربه (.*)$') or text:match('^مضاربة (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
if Redis:get(Fast.."iiooooo" .. msg.sender_id.user_id) then
local time = ctime(Redis:ttl(Fast.."iiooooo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يمكنك تضارب الان\n⋆ تعال بعد ( "..time.." )","md",true)
end
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(coniss) < 99 then
return bot.sendText(msg.chat_id,msg.id, "⋆ الحد الادنى المسموح هو 100 دولار 💸","md",true)
end
if tonumber(ballancee) < tonumber(coniss) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
local modarba = {"1", "2", "3", "4️",}
local Descriptioontt = modarba[math.random(#modarba)]
local modarbaa = math.random(1,90);
if Descriptioontt == "1" or Descriptioontt == "3" then
ballanceekku = coniss / 100 * modarbaa
ballanceekkku = ballancee - ballanceekku
local convert_mony = string.format("%.0f",ballanceekku)
local convert_mony1 = string.format("%.0f",ballanceekkku)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ballanceekkku))
Redis:setex(Fast.."iiooooo" .. msg.sender_id.user_id,900, true)
bot.sendText(msg.chat_id,msg.id, "⋆ مضاربة فاشلة 📉\n⋆ نسبة الخسارة ↜ "..modarbaa.."%\n⋆ المبلغ الذي خسرته ↜ ( "..convert_mony.." دولار 💸 )\n⋆ فلوسك اصبحت ↜ ( "..convert_mony1.." دولار 💸 )","md",true)
elseif Descriptioontt == "2" or Descriptioontt == "4" then
ballanceekku = coniss / 100 * modarbaa
ballanceekkku = ballancee + ballanceekku
local convert_mony = string.format("%.0f",ballanceekku)
local convert_mony1 = string.format("%.0f",ballanceekkku)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ballanceekkku))
Redis:setex(Fast.."iiooooo" .. msg.sender_id.user_id,900, true)
bot.sendText(msg.chat_id,msg.id, "⋆ مضاربة ناجحة 📈\n⋆ نسبة الربح ↜ "..modarbaa.."%\n⋆ المبلغ الذي ربحته ↜ ( "..convert_mony.." دولار 💸 )\n⋆ فلوسك اصبحت ↜ ( "..convert_mony1.." دولار 💸 )","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'استثمار' then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
if Redis:get(Fast.."iioooo" .. msg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."iioooo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يمكنك تستثمر الان\n⋆ تعال بعد ( "..time.." )","md",true)
end
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`استثمار` المبلغ","md",true)
end

if text and text:match('^استثمار (.*)$') then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local UserName = text:match('^استثمار (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
if Redis:get(Fast.."iioooo" .. msg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."iioooo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يمكنك تستثمر الان\n⋆ تعال بعد ( "..time.." )","md",true)
end
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(coniss) < 99 then
return bot.sendText(msg.chat_id,msg.id, "⋆ الحد الادنى المسموح هو 100 دولار 💸","md",true)
end
if tonumber(ballancee) < tonumber(coniss) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
if tonumber(ballancee) < 100000 then
local hadddd = math.random(10,15);
ballanceekk = coniss / 100 * hadddd
ballanceekkk = ballancee + ballanceekk
local convert_mony = string.format("%.0f",ballanceekk)
local convert_mony1 = string.format("%.0f",ballanceekkk)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ballanceekkk))
Redis:setex(Fast.."iioooo" .. msg.sender_id.user_id,1200, true)
bot.sendText(msg.chat_id,msg.id, "⋆ استثمار ناجح 💰\n⋆ نسبة الربح ↜ "..hadddd.."%\n⋆ مبلغ الربح ↜ ( "..convert_mony.." دولار 💸 )\n⋆ فلوسك اصبحت ↜ ( "..convert_mony1.." دولار 💸 )","md",true)
else
local hadddd = math.random(1,9);
ballanceekk = coniss / 100 * hadddd
ballanceekkk = ballancee + ballanceekk
local convert_mony = string.format("%.0f",ballanceekk)
local convert_mony1 = string.format("%.0f",ballanceekkk)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ballanceekkk))
Redis:setex(Fast.."iioooo" .. msg.sender_id.user_id,1200, true)
bot.sendText(msg.chat_id,msg.id, "⋆ استثمار ناجح 💰\n⋆ نسبة الربح ↜ "..hadddd.."%\n⋆ مبلغ الربح ↜ ( "..convert_mony.." دولار 💸 )\n⋆ فلوسك اصبحت ↜ ( "..convert_mony1.." دولار 💸 )","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'حظ' then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
if Redis:get(Fast.."iiooo" .. msg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."iiooo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يمكنك تلعب لعبة الحظ الان\n⋆ تعال بعد ( "..time.." )","md",true)
end
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`حظ` المبلغ","md",true)
end

if text and text:match('^حظ (.*)$') then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local UserName = text:match('^حظ (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
if Redis:get(Fast.."iiooo" .. msg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."iiooo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يمكنك تلعب لعبة الحظ الان\n⋆ تعال بعد ( "..time.." )","md",true)
end
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(ballancee) < tonumber(coniss) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end

local daddd = {"1", "2",}
local haddd = daddd[math.random(#daddd)]
if haddd == "1" then
local ballanceek = ballancee + coniss
local convert_mony = string.format("%.0f",ballancee)
local convert_mony1 = string.format("%.0f",ballanceek)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ballanceek))
Redis:setex(Fast.."iiooo" .. msg.sender_id.user_id,900, true)
bot.sendText(msg.chat_id,msg.id, "⋆ مبروك فزت بالحظ 🎉\n⋆ فلوسك قبل ↜ ( "..convert_mony.." دولار 💸 )\n⋆ فلوسك الان ↜ ( "..convert_mony1.." دولار 💸 )","md",true)
else
local ballanceekk = ballancee - coniss
local convert_mony = string.format("%.0f",ballancee)
local convert_mony1 = string.format("%.0f",ballanceekk)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ballanceekk))
Redis:setex(Fast.."iiooo" .. msg.sender_id.user_id,900, true)
bot.sendText(msg.chat_id,msg.id, "⋆ للاسف خسرت بالحظ 😬\n⋆ فلوسك قبل ↜ ( "..convert_mony.." دولار 💸 )\n⋆ فلوسك الان ↜ ( "..convert_mony1.." دولار 💸 )","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'تحويل' then
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`تحويل` المبلغ","md",true)
end

if text and text:match('^تحويل (.*)$') then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` لكي تستطيع التحويل","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local UserName = text:match('^تحويل (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if not Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
return bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ","md",true)
end
if tonumber(coniss) < 100 then
return bot.sendText(msg.chat_id,msg.id, "⋆ الحد الادنى المسموح به هو 100 دولار","md",true)
end
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(ballancee) < 100 then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end

if tonumber(coniss) > tonumber(ballancee) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end

Redis:set(Fast.."transn"..msg.sender_id.user_id,coniss)
Redis:setex(Fast.."trans" .. msg.chat_id .. ":" .. msg.sender_id.user_id,60, true)
bot.sendText(msg.chat_id,msg.id,[[
⋆ ارسل الان رقم الحساب البنكي الي تبي تحول له

– معاك دقيقة وحدة والغي طلب التحويل .
]],"md",true)  
return false
end
if Redis:get(Fast.."trans" .. msg.chat_id .. ":" .. msg.sender_id.user_id) then
cccc = Redis:get(Fast.."boobb"..msg.sender_id.user_id)
uuuu = Redis:get(Fast.."bbobb"..msg.sender_id.user_id)
if text ~= text:match('^(%d+)$') then
Redis:del(Fast.."trans" .. msg.chat_id .. ":" .. msg.sender_id.user_id) 
Redis:del(Fast.."transn" .. msg.sender_id.user_id)
return bot.sendText(msg.chat_id,msg.id,"⋆ ارسل رقم حساب بنكي ","md",true)
end
if text == cccc then
Redis:del(Fast.."trans" .. msg.chat_id .. ":" .. msg.sender_id.user_id) 
Redis:del(Fast.."transn" .. msg.sender_id.user_id)
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يمكنك تحول لنفسك ","md",true)
end
if Redis:get(Fast.."boballcc"..text) then
local UserNamey = Redis:get(Fast.."transn"..msg.sender_id.user_id)
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
news = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
news = " لا يوجد "
end
local fsvhhh = Redis:get(Fast.."boballid"..text)
local bann = bot.getUser(fsvhhh)
if bann.first_name then
newss = "["..bann.first_name.."](tg://user?id="..bann.id..")"
else
newss = " لا يوجد "
end
local fsvhh = Redis:get(Fast.."boballban"..text)
UserNameyr = UserNamey / 10
UserNameyy = UserNamey - UserNameyr
local convert_mony = string.format("%.0f",UserNameyy)
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
deccde = ballancee - UserNamey
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(deccde))
-----------
decdecb = Redis:get(Fast.."boob"..fsvhhh) or 0
deccde2 = decdecb + UserNameyy
Redis:set(Fast.."boob"..fsvhhh , math.floor(deccde2))

bot.sendText(msg.chat_id,msg.id, "حوالة صادرة من بنك جولد\n\nالمرسل : "..news.."\nالحساب رقم : `"..cccc.."`\nنوع البطاقة : "..uuuu.."\nالمستلم : "..newss.."\nالحساب رقم : `"..text.."`\nنوع البطاقة : "..fsvhh.."\nخصمت 10% رسوم تحويل\nالمبلغ : "..convert_mony.." دولار 💸","md",true)
bot.sendText(fsvhhh,0, "حوالة واردة من بنك جولد\n\nالمرسل : "..news.."\nالحساب رقم : `"..cccc.."`\nنوع البطاقة : "..uuuu.."\nالمبلغ : "..convert_mony.." دولار 💸","md",true)
Redis:del(Fast.."trans" .. msg.chat_id .. ":" .. msg.sender_id.user_id) 
Redis:del(Fast.."transn" .. msg.sender_id.user_id)
else
bot.sendText(msg.chat_id,msg.id, "⋆ مافيه حساب بنكي كذا","md",true)
Redis:del(Fast.."trans" .. msg.chat_id .. ":" .. msg.sender_id.user_id) 
Redis:del(Fast.."transn" .. msg.sender_id.user_id)
end
end


if text == "ترتيبي" then
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
local bank_users = Redis:smembers(Fast.."booob")
my_num_in_bank = {}
for k,v in pairs(bank_users) do
local mony = Redis:get(Fast.."boob"..v)
table.insert(my_num_in_bank, {math.floor(tonumber(mony)) , v})
end
table.sort(my_num_in_bank, function(a, b) return a[1] > b[1] end)
for k,v in pairs(my_num_in_bank) do
if tonumber(v[2]) == tonumber(msg.sender_id.user_id) then
local mony = v[1]
return bot.sendText(msg.chat_id,msg.id,"⋆ ترتيبك ( "..k.." )","md",true)
end
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == "توب فلوس" or text == "توب الفلوس" then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local bank_users = Redis:smembers(Fast.."booob")
if #bank_users == 0 then
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يوجد حسابات في البنك","md",true)
end
top_mony = "قائمه اغني 20 شخص بالبوت:\n\n"
mony_list = {}
for k,v in pairs(bank_users) do
local mony = Redis:get(Fast.."boob"..v)
table.insert(mony_list, {tonumber(mony) , v})
end
table.sort(mony_list, function(a, b) return a[1] > b[1] end)
num = 1
emoji ={ 
"🥇" ,
"🥈",
"🥉",
"4)",
"5)",
"6)",
"7)",
"8)",
"9)",
"10)",
"11)",
"12)",
"13)",
"14)",
"15)",
"16)",
"17)",
"18)",
"19)",
"20)"
}
for k,v in pairs(mony_list) do
if num <= 20 then
local user_name = bot.getUser(v[2]).first_name or Redis:get(v[2].."first_name:") or "لا يوجد اسم"
local mony = v[1]
local convert_mony = string.format("%.0f",mony)
local emo = emoji[k]
num = num + 1
top_mony = top_mony..emo.." "..convert_mony.." 💸 | "..user_name.."\n"
end
end
top_monyy = top_mony.."\n\nاي اسم مخالف او غش باللعب راح يتصفر وينحظر اللاعب"
return bot.sendText(msg.chat_id,msg.id,top_monyy,"md",false, false, false, false, reply_markup)
end

if text == "توب الحراميه" or text == "توب الحرامية" or text == "توب حراميه" or text == "توب الزرف" or text == "توب زرف" then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local ty_users = Redis:smembers(Fast.."rrfffid")
if #ty_users == 0 then
return bot.sendText(msg.chat_id,msg.id,"⋆ لا يوجد احد","md",true)
end
ty_anubis = "توب 20 شخص زرفوا فلوس :\n\n"
ty_list = {}
for k,v in pairs(ty_users) do
local mony = Redis:get(Fast.."rrfff"..v)
table.insert(ty_list, {tonumber(mony) , v})
end
table.sort(ty_list, function(a, b) return a[1] > b[1] end)
num_ty = 1
emojii ={ 
"🥇" ,
"🥈",
"🥉",
"4)",
"5)",
"6)",
"7)",
"8)",
"9)",
"10)",
"11)",
"12)",
"13)",
"14)",
"15)",
"16)",
"17)",
"18)",
"19)",
"20)"
}
for k,v in pairs(ty_list) do
if num_ty <= 20 then
local user_name = bot.getUser(v[2]).first_name or Redis:get(v[2].."first_name:") or "لا يوجد اسم"
local mony = v[1]
local convert_mony = string.format("%.0f",mony)
local emoo = emojii[k]
num_ty = num_ty + 1
ty_anubis = ty_anubis..emoo.." "..convert_mony.." 💸 | "..user_name.."\n"
end
end
ty_anubiss = ty_anubis.."\n\nاي اسم مخالف او غش باللعب راح يتصفر وينحظر اللاعب"
return bot.sendText(msg.chat_id,msg.id,ty_anubiss,"md",false, false, false, false, reply_markup)
end

if text == 'تسديد قرضه' and tonumber(msg.reply_to_message_id) ~= 0 then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ ليس لديه حساب في بنك جولد*","md",true)  
return false
end
if Redis:sismember(Fast.."booob",Remsg.sender_id.user_id) then
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) then
return bot.sendText(msg.chat_id,msg.id, "⋆ سدد قرضك اول شي بعدين اعمل راعي النشامى ","md",true)
end
if not Redis:get(Fast.."kreed"..Remsg.sender_id.user_id) then
return bot.sendText(msg.chat_id,msg.id, "⋆ ماعليه قرض","md",true)
else
local ban = bot.getUser(Remsg.sender_id.user_id)
if ban.first_name then
news = ""..ban.first_name..""
else
news = " لا يوجد"
end
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..Remsg.sender_id.user_id))
if tonumber(ballanceed) < tonumber(krses) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
nshme = ballanceed - krses
Redis:set(Fast.."boob"..msg.sender_id.user_id,math.floor(nshme))
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
Redis:del(Fast.."kreed"..Remsg.sender_id.user_id)
Redis:del(Fast.."kreednum"..Remsg.sender_id.user_id)
local convert_mony = string.format("%.0f",ballanceed)
bot.sendText(msg.chat_id,msg.id, "⋆ اشعار تسديد قرض عن "..news.."\n\nالقرض : "..krses.." دولار 💸\nتم اقتطاع المبلغ من فلوسك\nفلوسك الان : "..convert_mony.." دولار 💸 ","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعنده حساب بنكي ","md",true)
end
end

if text == 'تسديد قرض' or text == 'تسديد القرض' or text == 'تسديد قرضي' and tonumber(msg.reply_to_message_id) == 0 then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
if not Redis:get(Fast.."kreed"..msg.sender_id.user_id) then
return bot.sendText(msg.chat_id,msg.id, "⋆ ماعليك قرض ","md",true)
end
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if tonumber(ballanceed) < tonumber(krses) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
tsded = ballanceed - krses
Redis:set(Fast.."boob"..msg.sender_id.user_id,math.floor(tsded))
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
Redis:del(Fast.."kreed"..msg.sender_id.user_id)
Redis:del(Fast.."kreednum"..msg.sender_id.user_id)
local convert_mony = string.format("%.0f",ballanceed)
bot.sendText(msg.chat_id,msg.id, "⋆ اشعار تسديد قرض\n\n⋆ القرض : "..krses.." دولار 💸\nتم اقتطاع المبلغ من فلوسك\nفلوسك الان : "..convert_mony.." دولار 💸","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'القرض' or text == 'قرض' then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) then
return bot.sendText(msg.chat_id,msg.id, "⋆ سحبت قرض قبل بقيمة "..krses.." دولار 💸","md",true)
end
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(ballanceed) < 100000 then
kredd = tonumber(ballanceed) + 900000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,900000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 900000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 200000 then
kredd = tonumber(ballanceed) + 800000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,800000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 800000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 300000 then
kredd = tonumber(ballanceed) + 700000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,700000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 700000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 400000 then
kredd = tonumber(ballanceed) + 600000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,600000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 600000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 500000 then
kredd = tonumber(ballanceed) + 500000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,500000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 500000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 600000 then
kredd = tonumber(ballanceed) + 400000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,400000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 400000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 700000 then
kredd = tonumber(ballanceed) + 300000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,300000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 300000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 800000 then
kredd = tonumber(ballanceed) + 200000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,200000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 200000 دولار 💸","md",true)
elseif tonumber(ballanceed) < 900000 then
kredd = tonumber(ballanceed) + 100000
Redis:set(Fast.."boob"..msg.sender_id.user_id,kredd)
Redis:set(Fast.."kreednum"..msg.sender_id.user_id,100000)
Redis:set(Fast.."kreed"..msg.sender_id.user_id,true)
bot.sendText(msg.chat_id,msg.id, "⋆ ابشر وهي قرض بقيمة 100000 دولار 💸","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك فوق المليون مايطلعلك قرض","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'بخشيش' or text == 'بقشيش' then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
if Redis:ttl(Fast.."iioo" .. msg.sender_id.user_id) >=1 then
local hours = Redis:ttl(Fast.."iioo" .. msg.sender_id.user_id) / 60
return bot.sendText(msg.chat_id,msg.id,"⋆ من شوي اخذت بخشيش استنى "..math.floor(hours).." دقيقة","md",true)
end

local jjjo = math.random(200,1000);
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
bakigcj = ballanceed + jjjo
Redis:set(Fast.."boob"..msg.sender_id.user_id , bakigcj)
bot.sendText(msg.chat_id,msg.id,"⋆ تكرم وهي بخشيش "..jjjo.." دولار 💸","md",true)
Redis:setex(Fast.."iioo" .. msg.sender_id.user_id,600, true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'زرف' and tonumber(msg.reply_to_message_id) == 0 then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`زرف` بالرد","md",true)
end

if text == 'زرف' or text == 'زرفو' or text == 'زرفه' and tonumber(msg.reply_to_message_id) ~= 0 then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ ليس لديه حساب في بنك جولد*","md",true)  
return false
end
if Remsg.sender_id.user_id == msg.sender_id.user_id then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ بدك تزرف نفسك 🤡*","md",true)  
return false
end
if Redis:get(Fast.."polic" .. msg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."polic" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ انتا بالسجن 🏤 استنى ( "..time.." )","md",true)
end
if Redis:get(Fast.."hrame" .. Remsg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."hrame" .. Remsg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ ذا المسكين مزروف قبل شوي\n⋆ يمديك تزرفه بعد ( "..time.." )","md",true)
end
if Redis:sismember(Fast.."booob",Remsg.sender_id.user_id) then
ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
if tonumber(ballanceed) < 199 then
return bot.sendText(msg.chat_id,msg.id, "⋆ لا يمكنك تزرفه فلوسه اقل من 200 دولار 💸","md",true)
end
local hrame = math.floor(math.random() * 200) + 1;
local hramee = math.floor(math.random() * 5) + 1;
if hramee == 1 or hramee == 2 or hramee == 3 or hramee == 4 then
local ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
local ballancope = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
zrfne = ballanceed - hrame
zrfnee = ballancope + hrame
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(zrfnee))
Redis:set(Fast.."boob"..Remsg.sender_id.user_id , math.floor(zrfne))
Redis:setex(Fast.."hrame" .. Remsg.sender_id.user_id,900, true)
local zoropeo = Redis:get(Fast.."rrfff"..msg.sender_id.user_id) or 0
zoroprod = zoropeo + hrame
Redis:set(Fast.."rrfff"..msg.sender_id.user_id,zoroprod)
Redis:sadd(Fast.."rrfffid",msg.sender_id.user_id)
bot.sendText(msg.chat_id,msg.id, "⋆ خذ يالحرامي زرفته "..hrame.." دولار 💸","md",true)
else
Redis:setex(Fast.."polic" .. msg.sender_id.user_id,300, true)
bot.sendText(msg.chat_id,msg.id, "⋆ مسكتك الشرطة وانتا تزرف 🚔","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعنده حساب بنكي ","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'راتب' or text == 'راتبي' then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
if Redis:get(Fast.."iiioo" .. msg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."iiioo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ راتبك بينزل بعد ( "..time.." )","md",true)
end

local Textinggt = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52",}
local Descriptioont = Textinggt[math.random(#Textinggt)]
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
neews = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
neews = " لا يوجد "
end
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if Descriptioont == "1" then
local ratpep = ballancee + 3000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3000 دولار 💸\nوظيفتك : كابتن كريم 🚙\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "2" then
local ratpep = ballancee + 3500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3500 دولار 💸\nوظيفتك : شرطي 👮🏻‍♂️\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "3" then
local ratpep = ballancee + 3500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3500 دولار 💸\nوظيفتك : بياع حبوب 🍻\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "4" then
local ratpep = ballancee + 3000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3000 دولار 💸\nوظيفتك : سواق تاكسي 🚕\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "5" then
local ratpep = ballancee + 5000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5000 دولار 💸\nوظيفتك : قاضي 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "6" then
local ratpep = ballancee + 2500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2500 دولار 💸\nوظيفتك : نوم 🛌\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "7" then
local ratpep = ballancee + 2700
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2700 دولار 💸\nوظيفتك : مغني 🎤\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "8" then
local ratpep = ballancee + 2900
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2900 دولار 💸\nوظيفتك : كوفيره 💆\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "9" then
local ratpep = ballancee + 2500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2500 دولار 💸\nوظيفتك : ربة منزل 🤷\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "10" then
local ratpep = ballancee + 2900
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2900 دولار 💸\nوظيفتك : مربيه اطفال 💁\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "11" then
local ratpep = ballancee + 3700
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3700 دولار 💸\nوظيفتك : كهربائي 💡\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "12" then
local ratpep = ballancee + 3600
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3600 دولار 💸\nوظيفتك : نجار ⛏\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "13" then
local ratpep = ballancee + 2400
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2400 دولار 💸\nوظيفتك : متذوق طعام 🍕\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "14" then
local ratpep = ballancee + 3000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3000 دولار 💸\nوظيفتك : فلاح 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "15" then
local ratpep = ballancee + 5000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5000 دولار 💸\nوظيفتك : كاشير بنده 🙋\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "16" then
local ratpep = ballancee + 6000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6000 دولار 💸\nوظيفتك : ممرض 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "17" then
local ratpep = ballancee + 3100
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3100 دولار 💸\nوظيفتك : مهرج 🤹\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "18" then
local ratpep = ballancee + 3300
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3300 دولار 💸\nوظيفتك : عامل توصيل 🚴\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "19" then
local ratpep = ballancee + 4800
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 4800 دولار 💸\nوظيفتك : عسكري 👮\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "20" then
local ratpep = ballancee + 6000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6000 دولار 💸\nوظيفتك : مهندس 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "21" then
local ratpep = ballancee + 8000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 8000 دولار 💸\nوظيفتك : وزير 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "22" then
local ratpep = ballancee + 5500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5500 دولار 💸\nوظيفتك : محامي ⚖️\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "23" then
local ratpep = ballancee + 5500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5500 دولار 💸\nوظيفتك : تاجر 💸\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "24" then
local ratpep = ballancee + 7000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 7000 دولار 💸\nوظيفتك : دكتور 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "25" then
local ratpep = ballancee + 2600
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2600 دولار 💸\nوظيفتك : حفار قبور ⚓\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "26" then
local ratpep = ballancee + 3000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3000 دولار 💸\nوظيفتك : حلاق ✂\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "27" then
local ratpep = ballancee + 5000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5000 دولار 💸\nوظيفتك : إمام مسجد 📿\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "28" then
local ratpep = ballancee + 3000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3000 دولار 💸\nوظيفتك : صياد 🎣\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "29" then
local ratpep = ballancee + 2300
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2300 دولار 💸\nوظيفتك : خياط 🧵\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "30" then
local ratpep = ballancee + 7100
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 7100 دولار 💸\nوظيفتك : طيار 🛩\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "31" then
local ratpep = ballancee + 5300
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5300 دولار 💸\nوظيفتك : مودل 🕴\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "32" then
local ratpep = ballancee + 10000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 10000 دولار 💸\nوظيفتك : ملك 👑\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "33" then
local ratpep = ballancee + 2700
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 2700 دولار 💸\nوظيفتك : سباك 🔧\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "34" then
local ratpep = ballancee + 3900
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3900 دولار 💸\nوظيفتك : موزع 🗺\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "35" then
local ratpep = ballancee + 4100
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 4100 دولار 💸\nوظيفتك : سكيورتي 👮\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "36" then
local ratpep = ballancee + 3500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3500 دولار 💸\nوظيفتك : معلم شاورما 🌯\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "37" then
local ratpep = ballancee + 6700
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6700 دولار 💸\nوظيفتك : دكتور ولاده 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "38" then
local ratpep = ballancee + 6600
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6600 دولار 💸\nوظيفتك : مذيع 🗣\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "39" then
local ratpep = ballancee + 3400
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3400 دولار 💸\nوظيفتك : عامل مساج 💆\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "40" then
local ratpep = ballancee + 6300
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6300 دولار 💸\nوظيفتك : ممثل 🤵\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "41" then
local ratpep = ballancee + 3000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3000 دولار 💸\nوظيفتك : جزار 🥩\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "42" then
local ratpep = ballancee + 7000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 7000 دولار 💸\nوظيفتك : مدير بنك 💳\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "43" then
local ratpep = ballancee + 6000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6000 دولار 💸\nوظيفتك : مبرمج 👨\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "44" then
local ratpep = ballancee + 5000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5000 دولار 💸\nوظيفتك : رقاصه 💃\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "45" then
local ratpep = ballancee + 4900
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 4900 دولار 💸\nوظيفتك : 👩🏼‍💻 صحفي\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "46" then
local ratpep = ballancee + 5300
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 5300 دولار 💸\nوظيفتك : 🥷 حرامي\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "47" then
local ratpep = ballancee + 6000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6000 دولار 💸\nوظيفتك : 🔮 ساحر\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "48" then
local ratpep = ballancee + 6500
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 6500 دولار 💸\nوظيفتك : ⚽ لاعب️\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "49" then
local ratpep = ballancee + 4000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 4000 دولار 💸\nوظيفتك : 🖼 مصور\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "50" then
local ratpep = ballancee + 3000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3000 دولار 💸\nوظيفتك : ☎️ عامل مقسم\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "51" then
local ratpep = ballancee + 3200
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 3200 دولار 💸\nوظيفتك : 📖 كاتب\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
elseif Descriptioont == "52" then
local ratpep = ballancee + 4000
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(ratpep))
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,"اشعار ايداع "..neews.."\nالمبلغ : 4000 دولار 💸\nوظيفتك : 🧪 مخبري\nنوع العملية : اضافة راتب\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."iiioo" .. msg.sender_id.user_id,600, true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == 'هجوم' then
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`هجوم` المبلغ ( بالرد )","md",true)
end
if text and text:match("^هجوم (%d+)$") and msg.reply_to_message_id == 0 then
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`هجوم` المبلغ ( بالرد )","md",true)
end

if text and text:match('^هجوم (.*)$') and tonumber(msg.reply_to_message_id) ~= 0 then
local UserName = text:match('^هجوم (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ ليس لديه حساب في بنك جولد*","md",true)  
return false
end
if Remsg.sender_id.user_id == msg.sender_id.user_id then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ تهاجم نفسك 🤡*","md",true)  
return false
end
if Redis:get(Fast.."attack" .. msg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."attack" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ خسرت بأخر معركة استنى ( "..time.." )","md",true)
end
if Redis:get(Fast.."defen" .. Remsg.sender_id.user_id) then
  local time = ctime(Redis:ttl(Fast.."defen" .. Remsg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ الخصم خسر بأخر معركة\n⋆ يمديك تهاجمه بعد ( "..time.." )","md",true)
end
if Redis:sismember(Fast.."booob",Remsg.sender_id.user_id) then
ballancope = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
if tonumber(ballancope) < 100000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ لا يمكنك تهجم فلوسك اقل من 100000 دولار 💸","md",true)
end
if tonumber(ballanceed) < 100000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ لا يمكنك تهجم عليه فلوسه اقل من 100000 دولار 💸","md",true)
end
if tonumber(coniss) < 9999 then
return bot.sendText(msg.chat_id,msg.id, "⋆ الحد الادنى المسموح هو 10000 دولار 💸","md",true)
end
if tonumber(ballancope) < tonumber(coniss) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
if tonumber(ballanceed) < tonumber(coniss) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسه ماتكفي","md",true)
end
local Textinggt = {"1", "2", "3", "4", "5", "6", "7", "8",}
local Descriptioont = Textinggt[math.random(#Textinggt)]
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
neews = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
neews = " لا يوجد "
end
local bann = bot.getUser(Remsg.sender_id.user_id)
if bann.first_name then
neewss = "["..bann.first_name.."](tg://user?id="..bann.id..")"
else
neewss = " لا يوجد "
end
if Descriptioont == "1" or Descriptioont == "3" then
local ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
local ballancope = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
zrfne = ballancope - coniss
zrfnee = ballanceed + coniss
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(zrfne))
Redis:set(Fast.."boob"..Remsg.sender_id.user_id , math.floor(zrfnee))
Redis:setex(Fast.."attack" .. msg.sender_id.user_id,600, true)
local convert_mony = string.format("%.0f",coniss)
bot.sendText(msg.chat_id,msg.id, "⋆ لقد خسرت في المعركة "..neews.." 🛡\nالفائز : "..neewss.."\nالخاسر : "..neews.."\nالجائزة : "..convert_mony.." دولار 💸","md",true)
elseif Descriptioont == "2" or Descriptioont == "4" or Descriptioont == "5" or  Descriptioont == "6" or Descriptioont == "8" then
local ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
local ballancope = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
begaatt = Redis:get(Fast.."numattack"..msg.sender_id.user_id) or 1000
numattackk = tonumber(begaatt) - 1
if numattackk == 0 then
numattackk = 1
end
attack = coniss / numattackk
zrfne = ballancope + math.floor(attack)
zrfnee = ballanceed - math.floor(attack)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(zrfne))
Redis:set(Fast.."boob"..Remsg.sender_id.user_id , math.floor(zrfnee))
Redis:setex(Fast.."defen" .. Remsg.sender_id.user_id,1800, true)
Redis:set(Fast.."numattack"..msg.sender_id.user_id , math.floor(numattackk))
local convert_mony = string.format("%.0f",math.floor(attack))
bot.sendText(msg.chat_id,msg.id, "⋆ لقد فزت في المعركة\nودمرت قلعة "..neewss.." 🏰\nالفائز : "..neews.."\nالخاسر : "..neewss.."\nالجائزة : "..convert_mony.." دولار 💸\nنسبة قوة المهاجم اصبحت "..numattackk.." 🩸","md",true)
elseif Descriptioont == "7" then
local ballanceed = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
local ballancope = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
halfzrf = coniss / 2
zrfne = ballancope - halfzrf
zrfnee = ballanceed + halfzrf
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(zrfne))
Redis:set(Fast.."boob"..Remsg.sender_id.user_id , math.floor(zrfnee))
Redis:setex(Fast.."attack" .. msg.sender_id.user_id,600, true)
local convert_mony = string.format("%.0f",math.floor(halfzrf))
bot.sendText(msg.chat_id,msg.id, "⋆ لقد خسرت في المعركة "..neews.." 🛡\nولكن استطعت اعادة نصف الموارد\nالفائز : "..neewss.."\nالخاسر : "..neews.."\nالجائزة : "..convert_mony.." دولار 💸","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعنده حساب بنكي ","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end
if text == 'مسح لعبه الزواج' then
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
local zwag_users = Redis:smembers(Fast.."roogg1")
for k,v in pairs(zwag_users) do
Redis:del(Fast.."roog1"..v)
Redis:del(Fast.."rooga1"..v)
Redis:del(Fast.."rahr1"..v)
Redis:del(Fast.."rahrr1"..v)
Redis:del(Fast.."roogte1"..v)
end
local zwaga_users = Redis:smembers(Fast.."roogga1")
for k,v in pairs(zwaga_users) do
Redis:del(Fast.."roog1"..v)
Redis:del(Fast.."rooga1"..v)
Redis:del(Fast.."rahr1"..v)
Redis:del(Fast.."rahrr1"..v)
Redis:del(Fast.."roogte1"..v)
end
Redis:del(Fast.."roogga1")
Redis:del(Fast.."roogg1")
bot.sendText(msg.chat_id,msg.id, "⋆ مسحت لعبه الزواج","md",true)
end
end
if text == 'زوا.ج' then
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا:\n`زواج` المهر","md",true)
end
if text and text:match("^زواج (%d+)$") and msg.reply_to_message_id == 0 then
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا:\n`زواج` المهر ( بالرد )","md",true)
end
if text and text:match("^زواج (.*)$") and msg.reply_to_message_id ~= 0 then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local UserName = text:match('^زواج (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if msg.sender_id.user_id == Remsg.sender_id.user_id then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ زوجتك نفسي 🤣😒*","md",true)  
return false
end
if tonumber(coniss) < 10000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ الحد الادنى المسموح به هو 10000 دولار","md",true)
end
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(ballancee) < 10000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
if tonumber(coniss) > tonumber(ballancee) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ جولد مو للزواج 🤣*","md",true)  
return false
end
if Redis:get(Fast.."roog1"..msg.sender_id.user_id) then
bot.sendText(msg.chat_id,msg.id, "⋆ ابك تراك متزوج !!","md",true)
return false
end
if Redis:get(Fast.."rooga1"..msg.sender_id.user_id) then
bot.sendText(msg.chat_id,msg.id, "⋆ ابك تراك متزوج !!","md",true)
return false
end
if Redis:get(Fast.."roog1"..Remsg.sender_id.user_id) then
bot.sendText(msg.chat_id,msg.id, "⋆ ابعد بعيد لاتحوس وتدور حول المتزوجين","md",true)
return false
end
if Redis:get(Fast.."rooga1"..Remsg.sender_id.user_id) then
bot.sendText(msg.chat_id,msg.id, "⋆ ابعد بعيد لاتحوس وتدور حول المتزوجين","md",true)
return false
end
local bandd = bot.getUser(msg.sender_id.user_id)
if bandd.first_name then
neews = "["..bandd.first_name.."](tg://user?id="..bandd.id..")"
else
neews = " لا يوجد"
end
local ban = bot.getUser(Remsg.sender_id.user_id)
if ban.first_name then
newws = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
newws = " لا يوجد"
end
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
local hadddd = tonumber(coniss)
ballanceekk = tonumber(coniss) / 100 * 15
ballanceekkk = tonumber(coniss) - ballanceekk
local convert_mony = string.format("%.0f",ballanceekkk)
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
ballanceea = Redis:get(Fast.."boob"..Remsg.sender_id.user_id) or 0
zogtea = ballanceea + ballanceekkk
zeugh = ballancee - tonumber(coniss)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(zeugh))
Redis:set(Fast.."boob"..Remsg.sender_id.user_id , math.floor(zogtea))
Redis:sadd(Fast.."roogg1",msg.sender_id.user_id)
Redis:sadd(Fast.."roogga1",Remsg.sender_id.user_id)
Redis:set(Fast.."roog1"..msg.sender_id.user_id,msg.sender_id.user_id)
Redis:set(Fast.."rooga1"..msg.sender_id.user_id,Remsg.sender_id.user_id)
Redis:set(Fast.."roogte1"..Remsg.sender_id.user_id,Remsg.sender_id.user_id)
Redis:set(Fast.."rahr1"..msg.sender_id.user_id,tonumber(coniss))
Redis:set(Fast.."rahr1"..Remsg.sender_id.user_id,tonumber(coniss))

Redis:set(Fast.."roog1"..Remsg.sender_id.user_id,msg.sender_id.user_id)
Redis:set(Fast.."rahrr1"..msg.sender_id.user_id,math.floor(ballanceekkk))

Redis:set(Fast.."rooga1"..Remsg.sender_id.user_id,Remsg.sender_id.user_id)
Redis:set(Fast.."rahrr1"..Remsg.sender_id.user_id,math.floor(ballanceekkk))

bot.sendText(msg.chat_id,msg.id, "كولولولولويششش\nاليوم عقدنا قران :\n\nالزوج "..neews.." 🤵🏻\nالزوجة "..newws.." 👰🏻‍♀️\nالمهر : "..convert_mony.." دولار بعد الضريبة 15%\nعشان تشوفون وثيقة زواجكم اكتبوا : *زواجي*","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end

if text == "زواجات غش" then
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
  local zwag_users = Redis:smembers(Fast.."roogg1")
  if #zwag_users == 0 then
  return bot.sendText(msg.chat_id,msg.id,"⋆ مافي زواجات حاليا","md",true)
  end
  top_zwag = "توب 30 اغلى زواجات :\n\n"
  zwag_list = {}
  for k,v in pairs(zwag_users) do
  local mahr = Redis:get(Fast.."rahr1"..v)
  local zwga = Redis:get(Fast.."rooga1"..v)
  table.insert(zwag_list, {tonumber(mahr) , v , zwga})
  end
  table.sort(zwag_list, function(a, b) return a[1] > b[1] end)
  znum = 1
  zwag_emoji ={ 
"🥇" ,
"🥈",
"🥉",
"4)",
"5)",
"6)",
"7)",
"8)",
"9)",
"10)",
"11)",
"12)",
"13)",
"14)",
"15)",
"16)",
"17)",
"18)",
"19)",
"20)",
"21)",
"22)",
"23)",
"24)",
"25)",
"26)",
"27)",
"28)",
"29)",
"30)"
  }
  for k,v in pairs(zwag_list) do
  if znum <= 30 then
  local zwg_name = bot.getUser(v[2]).first_name or Redis:get(v[2].."first_name:") or "لا يوجد اسم"
  local zwg_tag = '['..zwg_name..'](tg://user?id='..v[2]..')'
  local zwga_name = bot.getUser(v[3]).first_name or Redis:get(v[3].."first_name:") or "لا يوجد اسم"
  local zwga_tag = '['..zwg_name..'](tg://user?id='..v[3]..')'
  local mahr = v[1]
  local convert_mony = string.format("%.0f",mahr)
  local emo = zwag_emoji[k]
  znum = znum + 1
  top_zwag = top_zwag..emo.." "..convert_mony.." 💸 ꗝ "..zwg_tag.." 👫 "..zwga_tag.."\n"
  end
  end
return bot.sendText(msg.chat_id,msg.id,top_zwag,"md",false, false, false, false, reply_markup)
  end
  end

if text == "توب الزواجات" or text == "توب متزوجات" or text == "توب زوجات" or text == "توب زواجات" or text == "زواجات" or text == "الزواجات" then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
  local zwag_users = Redis:smembers(Fast.."roogg1")
  if #zwag_users == 0 then
  return bot.sendText(msg.chat_id,msg.id,"⋆ مافي زواجات حاليا","md",true)
  end
  top_zwag = "توب 20 اغلى زواجات :\n\n"
  zwag_list = {}
  for k,v in pairs(zwag_users) do
  local mahr = Redis:get(Fast.."rahr1"..v)
  local zwga = Redis:get(Fast.."rooga1"..v)
  table.insert(zwag_list, {tonumber(mahr) , v , zwga})
  end
  table.sort(zwag_list, function(a, b) return a[1] > b[1] end)
  znum = 1
  zwag_emoji ={ 
"🥇" ,
"🥈",
"🥉",
"4)",
"5)",
"6)",
"7)",
"8)",
"9)",
"10)",
"11)",
"12)",
"13)",
"14)",
"15)",
"16)",
"17)",
"18)",
"19)",
"20)"
  }
  for k,v in pairs(zwag_list) do
  if znum <= 20 then
  local zwg_name = bot.getUser(v[2]).first_name or Redis:get(v[2].."first_name:") or "لا يوجد اسم"
  local zwga_name = bot.getUser(v[3]).first_name or Redis:get(v[3].."first_name:") or "لا يوجد اسم"
  local mahr = v[1]
  local convert_mony = string.format("%.0f",mahr)
  local emo = zwag_emoji[k]
  znum = znum + 1
  top_zwag = top_zwag..emo.." "..convert_mony.." 💸 "..zwg_name.." 👫 "..zwga_name.."\n"
  end
  end
return bot.sendText(msg.chat_id,msg.id,top_zwag,"md",false, false, false, false, reply_markup)
  end

if text == 'زواجي' then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."roogg1",msg.sender_id.user_id) or Redis:sismember(Fast.."roogga1",msg.sender_id.user_id) then
local zoog = Redis:get(Fast.."roog1"..msg.sender_id.user_id)
local zooga = Redis:get(Fast.."rooga1"..msg.sender_id.user_id)
local mahr = Redis:get(Fast.."rahr1"..msg.sender_id.user_id)
local convert_mony = string.format("%.0f",mahr)
local bandd = bot.getUser(zoog)
if bandd.first_name then
neews = "["..bandd.first_name.."](tg://user?id="..bandd.id..")"
else
neews = " لا يوجد"
end
local ban = bot.getUser(zooga)
if ban.first_name then
newws = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
newws = " لا يوجد"
end
bot.sendText(msg.chat_id,msg.id, "وثيقة الزواج حقتك :\n\nالزوج "..neews.." 🤵🏻\nالزوجة "..newws.." 👰🏻‍♀️\nالمهر : "..convert_mony.." دولار 💸","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ انت اعزب","md",true)
end
end

if text == 'زوجها' or text == "زوجته" or text == "جوزها" or text == "زوجتو" or text == "زواجه" and msg.reply_to_message_id ~= 0 then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if msg.sender_id.user_id == Remsg.sender_id.user_id then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ لا تكشف نفسك وتخسر فلوس عالفاضي\n اكتب `زواجي`*","md",true)  
return false
end
if Redis:sismember(Fast.."roogg1",Remsg.sender_id.user_id) or Redis:sismember(Fast.."roogga1",Remsg.sender_id.user_id) then
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(ballancee) < 100 then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
local Remsg = bot.getMessage(msg.chat_id, msg.reply_to_message_id)
local UserInfo = bot.getUser(Remsg.sender_id.user_id)
if UserInfo and UserInfo.type and UserInfo.type.Fastbots == "userTypeBot" then
bot.sendText(msg.chat_id,msg.id,"\n*⋆ جولد مو متزوجه 🤣*","md",true)  
return false
end
local zoog = Redis:get(Fast.."roog1"..Remsg.sender_id.user_id)
local zooga = Redis:get(Fast.."rooga1"..Remsg.sender_id.user_id)
local mahr = Redis:get(Fast.."rahr1"..Remsg.sender_id.user_id)
local bandd = bot.getUser(zoog)
if bandd.first_name then
neews = "["..bandd.first_name.."](tg://user?id="..bandd.id..")"
else
neews = " لا يوجد"
end
local ban = bot.getUser(zooga)
if ban.first_name then
newws = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
newws = " لا يوجد"
end
local otheka = ballancee - 100
local convert_mony = string.format("%.0f",mahr)
Redis:set(Fast.."boob"..msg.sender_id.user_id , math.floor(otheka))
bot.sendText(msg.chat_id,msg.id, "وثيقة الزواج حقته :\n\nالزوج "..neews.." 🤵🏻\nالزوجة "..newws.." 👰🏻‍\nالمهر : "..convert_mony.." دولار 💸","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ مسكين اعزب مو متزوج","md",true)
end
end

if text == 'طلاق' then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."roogg1",msg.sender_id.user_id) or Redis:sismember(Fast.."roogga1",msg.sender_id.user_id) then
local zoog = Redis:get(Fast.."roog1"..msg.sender_id.user_id)
local zooga = tonumber(Redis:get(Fast.."rooga1"..msg.sender_id.user_id))
if tonumber(zoog) == msg.sender_id.user_id then
local bandd = bot.getUser(zoog)
if bandd.first_name then
neews = "["..bandd.first_name.."](tg://user?id="..bandd.id..")"
else
neews = " لا يوجد"
end
local ban = bot.getUser(zooga)
if ban.first_name then
newws = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
newws = " لا يوجد"
end

Redis:srem(Fast.."roogg1", msg.sender_id.user_id)
Redis:srem(Fast.."roogga1", msg.sender_id.user_id)
Redis:del(Fast.."roog1"..msg.sender_id.user_id)
Redis:del(Fast.."rooga1"..msg.sender_id.user_id)
Redis:del(Fast.."rahr1"..msg.sender_id.user_id)
Redis:del(Fast.."rahrr1"..msg.sender_id.user_id)

Redis:srem(Fast.."roogg1", zooga)
Redis:srem(Fast.."roogga1", zooga)
Redis:del(Fast.."roog1"..zooga)
Redis:del(Fast.."rooga1"..zooga)
Redis:del(Fast.."rahr1"..zooga)
Redis:del(Fast.."rahrr1"..zooga)
return bot.sendText(msg.chat_id,msg.id, "⋆ تم طلقتك من زوجتك "..newws.."","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ الطلاق للزوج فقط","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ انت اعزب","md",true)
end
end

if text == 'خلع' then
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."roogg1",msg.sender_id.user_id) or Redis:sismember(Fast.."roogga1",msg.sender_id.user_id) then
local zoog = Redis:get(Fast.."roog1"..msg.sender_id.user_id)
local zooga = Redis:get(Fast.."rooga1"..msg.sender_id.user_id)
if tonumber(zooga) == msg.sender_id.user_id then
local mahrr = Redis:get(Fast.."rahrr1"..msg.sender_id.user_id)
local bandd = bot.getUser(zoog)
if bandd.first_name then
neews = "["..bandd.first_name.."](tg://user?id="..bandd.id..")"
else
neews = " لا يوجد"
end
local ban = bot.getUser(zooga)
if ban.first_name then
newws = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
newws = " لا يوجد"
end

ballancee = Redis:get(Fast.."boob"..zoog) or 0
kalea = ballancee + mahrr
Redis:set(Fast.."boob"..zoog , kalea)
local convert_mony = string.format("%.0f",mahrr)
bot.sendText(msg.chat_id,msg.id, "⋆ خلعت زوجك "..neews.."\n⋆ ورجعت له المهر ( "..convert_mony.." دولار 💸 )","md",true)

Redis:srem(Fast.."roogg1", zoog)
Redis:srem(Fast.."roogga1", zoog)
Redis:del(Fast.."roog1"..zoog)
Redis:del(Fast.."rooga1"..zoog)
Redis:del(Fast.."rahr1"..zoog)
Redis:del(Fast.."rahrr1"..zoog)

Redis:srem(Fast.."roogg1", msg.sender_id.user_id)
Redis:srem(Fast.."roogga1", msg.sender_id.user_id)
Redis:del(Fast.."roog1"..msg.sender_id.user_id)
Redis:del(Fast.."rooga1"..msg.sender_id.user_id)
Redis:del(Fast.."rahr1"..msg.sender_id.user_id)
Redis:del(Fast.."rahrr1"..msg.sender_id.user_id)
else
bot.sendText(msg.chat_id,msg.id, "⋆ الخلع للزوجات فقط","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ انت اعزب","md",true)
end
end
if text == 'مراهنه' or text == 'مراهنة' then
bot.sendText(msg.chat_id,msg.id, "استعمل الامر كذا :\n\n`مراهنه` المبلغ","md",true)
end
if text and text:match('^مراهنه (.*)$') or text and text:match('^مراهنة (.*)$') then
local UserName = text:match('^مراهنه (.*)$') or text:match('^مراهنة (.*)$')
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if tonumber(ballancee) < tonumber(coniss) then
return bot.sendText(msg.chat_id,msg.id, "⋆ فلوسك ماتكفي","md",true)
end
Redis:del(Fast..'List_rhan'..msg.chat_id)  
Redis:set(Fast.."playerrhan"..msg.chat_id,msg.sender_id.user_id)
Redis:set(Fast.."playercoins"..msg.chat_id..msg.sender_id.user_id,coniss)
Redis:set(Fast.."raeahkam"..msg.chat_id,msg.sender_id.user_id)
Redis:sadd(Fast..'List_rhan'..msg.chat_id,msg.sender_id.user_id)
Redis:setex(Fast.."Start_rhan"..msg.chat_id,3600,true)
Redis:set(Fast.."allrhan"..msg.chat_id..12345 , coniss)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
rehan = tonumber(ballancee) - tonumber(coniss)
Redis:set(Fast.."boob"..msg.sender_id.user_id , rehan)
return bot.sendText(msg.chat_id,msg.id,"⋆ تم بدء المراهنة وتم تسجيلك \n⋆ اللي بده يشارك يرسل ( انا والمبلغ ) .","md",true)
end
if text == 'نعم' and Redis:get(Fast.."Witting_Startrhan"..msg.chat_id) then
rarahkam = Redis:get(Fast.."raeahkam"..msg.chat_id)
if tonumber(rarahkam) == msg.sender_id.user_id then
local list = Redis:smembers(Fast..'List_rhan'..msg.chat_id) 
if #list == 1 then 
return bot.sendText(msg.chat_id,msg.id,"⋆ عذراً لم يشارك احد بالرهان","md",true)  
end 
local UserName = list[math.random(#list)]
local UserId_Info = bot.getUser(UserName)
if UserId_Info.username and UserId_Info.username ~= "" then
ls = '['..UserId_Info.first_name..'](tg://user?id='..UserName..')'
else
ls = '@['..UserId_Info.username..']'
end
benrahan = Redis:get(Fast.."allrhan"..msg.chat_id..12345) or 0
local ballancee = Redis:get(Fast.."boob"..UserName) or 0
rehan = tonumber(ballancee) + tonumber(benrahan)
Redis:set(Fast.."boob"..UserName , rehan)

local rhan_users = Redis:smembers(Fast.."List_rhan"..msg.chat_id)
for k,v in pairs(rhan_users) do
Redis:del(Fast..'playercoins'..msg.chat_id..v)
end
Redis:del(Fast..'allrhan'..msg.chat_id..12345) 
Redis:del(Fast..'playerrhan'..msg.chat_id) 
Redis:del(Fast..'raeahkam'..msg.chat_id) 
Redis:del(Fast..'List_rhan'..msg.chat_id) 
Redis:del(Fast.."Witting_Startrhan"..msg.chat_id)
Redis:del(Fast.."Start_rhan"..msg.chat_id)
local ballancee = Redis:get(Fast.."boob"..UserName) or 0
local convert_mony = string.format("%.0f",benrahan)
local convert_monyy = string.format("%.0f",ballancee)
return bot.sendText(msg.chat_id,msg.id,'⋆ فاز '..ls..' بالرهان 🎊\nالمبلغ : '..convert_mony..' دولار 💸\nرصيدك الان : '..convert_monyy..' دولار 💸\n✦',"md",true)
end
end
--------------------------------------------------------------------------------------------------------------
if text == 'كنز' then
ballanceed = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
krses = tonumber(Redis:get(Fast.."kreednum"..msg.sender_id.user_id))
if Redis:get(Fast.."kreed"..msg.sender_id.user_id) and tonumber(ballanceed) > 5000000 then
return bot.sendText(msg.chat_id,msg.id, "⋆ عليك قرض بقيمة "..krses.." دولار 💸 \nقم بسداده بالامر `تسديد القرض` ","md",true)
end
local F_Name = bot.getUser(msg.sender_id.user_id).first_name
Redis:set(msg.sender_id.user_id.."first_name:", F_Name)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
if Redis:get(Fast.."yiioooo" .. msg.sender_id.user_id) then
local time = ctime(Redis:ttl(Fast.."yiioooo" .. msg.sender_id.user_id))
return bot.sendText(msg.chat_id,msg.id,"⋆ فرصة ايجاد كنز آخر بعد ( "..time.." )","md",true)
end
local Textinggt = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22","23",}
local Descriptioont = Textinggt[math.random(#Textinggt)]
local ban = bot.getUser(msg.sender_id.user_id)
if ban.first_name then
neews = "["..ban.first_name.."](tg://user?id="..ban.id..")"
else
neews = " لا يوجد "
end
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
if Descriptioont == "1" then
local knez = ballancee + 40000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : قطعة اثرية 🗳\nسعره : 40000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "2" then
local knez = ballancee + 35000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : حجر الماسي 💎\nسعره : 35000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "3" then
local knez = ballancee + 10000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : لباس قديم 🥻\nسعره : 10000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "4" then
local knez = ballancee + 23000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : عصى سحرية 🪄\nسعره : 23000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "5" then
local knez = ballancee + 8000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : جوال نوكيا 📱\nسعره : 8000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "6" then
local knez = ballancee + 27000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : صدف 🏝\nسعره : 27000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "7" then
local knez = ballancee + 18000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : ابريق صدئ ⚗️\nسعره : 18000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "8" then
local knez = ballancee + 100000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : قناع فرعوني 🗿\nسعره : 100000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "9" then
local knez = ballancee + 50000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : جرة ذهب 💰\nسعره : 50000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "10" then
local knez = ballancee + 36000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : مصباح فضي 🔦\nسعره : 36000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "11" then
local knez = ballancee + 29000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : لوحة نحاسية 🌇\nسعره : 29000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "12" then
local knez = ballancee + 1000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : جوارب قديمة 🧦\nسعره : 1000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "13" then
local knez = ballancee + 16000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : اناء فخاري ⚱️\nسعره : 16000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "14" then
local knez = ballancee + 12000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : خوذة محارب 🪖\nسعره : 12000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "15" then
local knez = ballancee + 19000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : سيف جدي مرزوق 🗡\nسعره : 19000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "16" then
local knez = ballancee + 14000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : مكنسة جدتي رقية 🧹\nسعره : 14000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "17" then
local knez = ballancee + 26000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : فأس ارطغرل 🪓\nسعره : 26000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "18" then
local knez = ballancee + 22000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : بندقية 🔫\nسعره : 22000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "19" then
local knez = ballancee + 11000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : كبريت ناري 🪔\nسعره : 11000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "20" then
local knez = ballancee + 33000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : فرو ثعلب 🦊\nسعره : 33000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "21" then
local knez = ballancee + 40000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : جلد تمساح 🐊\nسعره : 40000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "22" then
local knez = ballancee + 17000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : باقة ورود 💐\nسعره : 17000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioont == "23" then
local Textinggtt = {"1", "2",}
local Descriptioontt = Textinggtt[math.random(#Textinggtt)]
if Descriptioontt == "1" then
local knez = ballancee + 17000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : باقة ورود 💐\nسعره : 17000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioontt == "2" then
local Textinggttt = {"1", "2",}
local Descriptioonttt = Textinggttt[math.random(#Textinggttt)]
if Descriptioonttt == "1" then
local knez = ballancee + 40000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : جلد تمساح 🐊\nسعره : 40000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
elseif Descriptioonttt == "2" then
local knez = ballancee + 10000000
Redis:set(Fast.."boob"..msg.sender_id.user_id , knez)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
bot.sendText(msg.chat_id,msg.id,""..neews.." لقد وجدت كنز\nالكنز : حقيبة محاسب البنك 💼\nسعره : 10000000 دولار 💸\nرصيدك الان : "..convert_mony.." دولار 💸","md",true)
Redis:setex(Fast.."yiioooo" .. msg.sender_id.user_id,1800, true)
end
end
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ارسل ↜ ( `انشاء حساب بنكي` )","md",true)
end
end
if text and text:match('^حظر حساب (.*)$') then
local UserName = text:match('^حظر حساب (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
Redis:set(Fast.."bandid"..coniss,coniss)
bot.sendText(msg.chat_id,msg.id, "⋆ تم حظر الحساب "..coniss.." من لعبة البنك","md",true)
end
end

if text and text:match('^الغاء حظر حساب (.*)$') then
local UserName = text:match('^الغاء حظر حساب (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
Redis:del(Fast.."bandid"..coniss)
bot.sendText(msg.chat_id,msg.id, "⋆ تم الغاء حظر الحساب "..coniss.." من لعبة البنك","md",true)
end
end

if text and text:match('^انشاء كوبون (.*)$') then
local UserName = text:match('^انشاء كوبون (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if tonumber(msg.sender_id.user_id) == tonumber(Sudo_Id) then
numcobo = math.random(1000000000000,9999999999999);
Redis:set(Fast.."cobonum"..numcobo,numcobo)
Redis:set(Fast.."cobon"..numcobo,coniss)
bot.sendText(msg.chat_id,msg.id, "⋆ وصل كوبون \n\nالمبلغ : "..coniss.." دولار 💸\nرقم الكوبون : `"..numcobo.."`\n\n⋆ طريقة استخدام الكوبون :\nتكتب ( كوبون + رقمه )\nمثال : كوبون 4593875","md",true)
end
end

if text == "كوبون" or text == "الكوبون" then
bot.sendText(msg.chat_id,msg.id, "⋆ طريقة استخدام الكوبون :\nتكتب ( كوبون + رقمه )\nمثال : كوبون 4593875\n\n- ملاحظة : الكوبون يستخدم لمرة واحدة ولشخص واحد","md",true)
end

if text and text:match('^كوبون (.*)$') then
local UserName = text:match('^كوبون (.*)$')
local coniss = tostring(UserName)
local coniss = coniss:gsub('٠','0')
local coniss = coniss:gsub('١','1')
local coniss = coniss:gsub('٢','2')
local coniss = coniss:gsub('٣','3')
local coniss = coniss:gsub('٤','4')
local coniss = coniss:gsub('٥','5')
local coniss = coniss:gsub('٦','6')
local coniss = coniss:gsub('٧','7')
local coniss = coniss:gsub('٨','8')
local coniss = coniss:gsub('٩','9')
local coniss = coniss:gsub('-','')
local coniss = tonumber(coniss)
if Redis:sismember(Fast.."booob",msg.sender_id.user_id) then
cobnum = Redis:get(Fast.."cobonum"..coniss)
if coniss == tonumber(cobnum) then
cobblc = Redis:get(Fast.."cobon"..coniss)
ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
cobonplus = ballancee + cobblc
Redis:set(Fast.."boob"..msg.sender_id.user_id , cobonplus)
local ballancee = Redis:get(Fast.."boob"..msg.sender_id.user_id) or 0
local convert_mony = string.format("%.0f",ballancee)
Redis:del(Fast.."cobon"..coniss)
Redis:del(Fast.."cobonum"..coniss)
bot.sendText(msg.chat_id,msg.id, "⋆ وصل كوبون \n\nالمبلغ : "..cobblc.." دولار 💸\nرقم الكوبون : `"..coniss.."`\nفلوسك الان : "..convert_mony.." دولار 💸","md",true)
else
bot.sendText(msg.chat_id,msg.id, "⋆ لا يوجد كوبون بهذا الرقم `"..coniss.."`","md",true)
end
else
bot.sendText(msg.chat_id,msg.id, "⋆ ماعندك حساب بنكي ","md",true)
end
end

end

return {Fast = bank}